package main

func main() { !3; }
