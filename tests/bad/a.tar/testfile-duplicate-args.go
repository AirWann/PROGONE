package main

func test(x int, x int) {}

func main() {}
