package main

func foo () (int, int) { if (3 >= 2) {return 2, 3 } else {return "test", 3 } }

func main () {}
