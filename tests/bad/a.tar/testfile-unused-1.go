package main
func main() { x := 1 }
