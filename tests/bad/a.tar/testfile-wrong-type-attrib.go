package main

type T struct {x, y int}
type S struct {x, y fezofjezoi}

func main() {}
