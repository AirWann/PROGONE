package main

func foo () {}
func foo () {}

func main () {}
