package main

func test(x deizd) {}

func main() {}
